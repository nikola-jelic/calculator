var searchData=
[
  ['calculator',['Calculator',['../index.html',1,'']]]
];
