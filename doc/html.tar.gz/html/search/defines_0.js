var searchData=
[
  ['in_5fbuf_5fsize',['IN_BUF_SIZE',['../lexer_8h.html#a08a7e8a6abdc5cf6d2ac4e978e084d1a',1,'lexer.h']]]
];
