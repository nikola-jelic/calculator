var searchData=
[
  ['scan_5flog',['scan_log',['../lexer_8h.html#a77b251be48a8185e685fd1db34bf4cd4',1,'scan_log(void):&#160;lexer.c'],['../lexer_8c.html#a77b251be48a8185e685fd1db34bf4cd4',1,'scan_log(void):&#160;lexer.c']]],
  ['scan_5fnumber',['scan_number',['../lexer_8h.html#a52b0989dbcece19aadbdc3442dacfe82',1,'scan_number(void):&#160;lexer.c'],['../lexer_8c.html#a52b0989dbcece19aadbdc3442dacfe82',1,'scan_number(void):&#160;lexer.c']]]
];
