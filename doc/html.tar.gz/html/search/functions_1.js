var searchData=
[
  ['calculate',['calculate',['../calc__element_8h.html#a61654e4f271f3113164d8f45acb79d9b',1,'calculate(CALC_ELEMENT **e):&#160;calc_element.c'],['../calc__element_8c.html#a61654e4f271f3113164d8f45acb79d9b',1,'calculate(CALC_ELEMENT **e):&#160;calc_element.c']]],
  ['canonical_5fform',['canonical_form',['../calc__element_8h.html#aa50b65cf18db529cb789bc9fe2e33145',1,'canonical_form(CALC_ELEMENT **e):&#160;calc_element.c'],['../calc__element_8c.html#aa50b65cf18db529cb789bc9fe2e33145',1,'canonical_form(CALC_ELEMENT **e):&#160;calc_element.c']]],
  ['cleanup',['cleanup',['../main_8c.html#aeb94fbd457627182ceee7e505f432541',1,'main.c']]],
  ['clear_5fline',['clear_line',['../lexer_8h.html#af521bfcde12ad6b4069a9c7f2d9f8c20',1,'clear_line(void):&#160;lexer.c'],['../lexer_8c.html#af521bfcde12ad6b4069a9c7f2d9f8c20',1,'clear_line(void):&#160;lexer.c']]],
  ['create_5fax_5fb',['create_ax_b',['../calc__element_8h.html#a9acd0569dfebffae72314768035d0a18',1,'create_ax_b(double a, double b):&#160;calc_element.c'],['../calc__element_8c.html#a9acd0569dfebffae72314768035d0a18',1,'create_ax_b(double a, double b):&#160;calc_element.c']]],
  ['create_5fbin_5fop',['create_bin_op',['../calc__element_8h.html#a72e3e738ea9c12a83ebc4c2c06b5796a',1,'create_bin_op(char op, CALC_ELEMENT *l, CALC_ELEMENT *r):&#160;calc_element.c'],['../calc__element_8c.html#a72e3e738ea9c12a83ebc4c2c06b5796a',1,'create_bin_op(char op, CALC_ELEMENT *l, CALC_ELEMENT *r):&#160;calc_element.c']]],
  ['create_5flog',['create_log',['../calc__element_8h.html#afa98ba9149abbfc389a1970ae6e1d670',1,'create_log(CALC_ELEMENT *e):&#160;calc_element.c'],['../calc__element_8c.html#afa98ba9149abbfc389a1970ae6e1d670',1,'create_log(CALC_ELEMENT *e):&#160;calc_element.c']]],
  ['create_5fnumber',['create_number',['../calc__element_8h.html#a2b7f1c44024367bcd12c2bdfacbf02b6',1,'create_number(double val):&#160;calc_element.c'],['../calc__element_8c.html#a2b7f1c44024367bcd12c2bdfacbf02b6',1,'create_number(double val):&#160;calc_element.c']]],
  ['create_5fx',['create_x',['../calc__element_8h.html#a365ee3980490b889f5a7295b9f450f97',1,'create_x(void):&#160;calc_element.c'],['../calc__element_8c.html#a365ee3980490b889f5a7295b9f450f97',1,'create_x(void):&#160;calc_element.c']]]
];
